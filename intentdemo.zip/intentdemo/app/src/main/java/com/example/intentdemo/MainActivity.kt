package com.example.intentdemo

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextInput: EditText
    private lateinit var btnOpenSecond: Button
    private lateinit var btnCallFriend: Button
    private lateinit var btnShare: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextInput = findViewById(R.id.editTextInput)
        btnOpenSecond = findViewById(R.id.btnOpenSecond)
        btnCallFriend = findViewById(R.id.btnCallFriend)
        btnShare = findViewById(R.id.btnShare)

        // 1. Явный Intent — открыть вторую Activity
        btnOpenSecond.setOnClickListener {
            val text = editTextInput.text.toString().trim()
            if (!validateText(text)) {
                Toast.makeText(this, "Введите непустой текст", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(this, SecondActivity::class.java).apply {
                putExtra("EXTRA_TEXT", text)
            }
            startActivity(intent)
        }

        // 2. Неявный Intent — ACTION_DIAL
        btnCallFriend.setOnClickListener {
            val phone = editTextInput.text.toString().trim()
            if (!validatePhone(phone)) {
                Toast.makeText(this, "Введите корректный номер телефона", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phone")
            }
            if (dialIntent.resolveActivity(packageManager) != null) {
                startActivity(dialIntent)
            } else {
                Toast.makeText(this, "Нет приложения для звонков", Toast.LENGTH_SHORT).show()
            }
        }

        // 3. Системный Intent — ACTION_SEND
        btnShare.setOnClickListener {
            val text = editTextInput.text.toString().trim()
            if (!validateText(text)) {
                Toast.makeText(this, "Введите текст для отправки", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            val chooserIntent = Intent.createChooser(shareIntent, "Поделиться через...")
            if (shareIntent.resolveActivity(packageManager) != null) {
                startActivity(chooserIntent)
            } else {
                Toast.makeText(this, "Нет приложений для обмена", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun validateText(text: String): Boolean = text.isNotBlank()

    private fun validatePhone(phone: String): Boolean {
        val normalized = phone.replace(Regex("[^0-9+]"), "")
        return normalized.length >= 7 && normalized.matches(Regex("^\\+?[0-9]+$"))
    }
}

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val textViewResult: TextView = findViewById(R.id.textViewResult)
        val receivedText = intent.getStringExtra("EXTRA_TEXT") ?: "Нет текста"
        textViewResult.text = receivedText
    }
}
